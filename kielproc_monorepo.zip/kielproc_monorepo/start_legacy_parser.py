import runpy; runpy.run_path('tools/legacy_parser/parser_gui.py', run_name='__main__')
